<?php $__env->startSection('content'); ?>
  <aside class="rights">
    <h3>Login Into Your Account</h3>
    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="radio">
        <label>
          <input type="radio" name="user_type" value="1">
          <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
          <span>Patients</span>
        </label>
        <label>
          <input type="radio" name="user_type" value="2">
          <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
          <span>Doctor</span>
        </label>
        <label>
          <input type="radio" name="user_type" value="3">
          <span class="cr"><i class="cr-icon fa fa-circle"></i></span>
          <span>Pharmacies</span>
        </label>
      </div>
      <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <input type="text" name="email" class="form-control users" placeholder="Username/Email">

        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
      </div>
      <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <input type="password" name="password" class="form-control pass" placeholder="Password">
        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <button class="btn btn-info col-md-12">Sign In</button>
      </div>
      <div class="row">
        <div class="col-md-12">
          <span><a href="<?php echo e(url('/password/reset')); ?>">Forgot Password</a></span>
          <span><a href="<?php echo e(url('/register')); ?>">Create An Account</a></span>
        </div>
      </div>
    </form>
  </aside>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>